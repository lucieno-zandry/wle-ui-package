import { Check, X } from "lucide-react";

interface ComparisonViewProps {
    eyebrow: string;
    title: string;
    subtitle: string;
    ourLabel: string;
    theirLabel: string;
    rows: Array<{ criteria: string; ours: string | boolean; theirs: string | boolean }>;
    criteriaLabel: string;
}

export function ComparisonView({
    eyebrow,
    title,
    subtitle,
    ourLabel,
    theirLabel,
    rows,
    criteriaLabel,
}: ComparisonViewProps) {
    return (
        <section className="py-xl bg-bark">
            <div className="max-w-content mx-auto px-md">
                <div className="mb-lg">
                    <p className="font-body text-[0.7rem] font-medium tracking-[0.18em] uppercase text-accent mb-xs !text-accent-light">{eyebrow}</p>
                    <h2 className="font-display text-[clamp(2rem,4vw,3.25rem)] font-medium leading-tight text-foreground mb-sm !text-primary-foreground">{title}</h2>
                    <p className="text-base text-foreground-mid max-w-text leading-relaxed !text-primary-foreground/55">{subtitle}</p>
                </div>
                <div className="overflow-x-auto rounded-md border border-white/10">
                    <table className="w-full min-w-[540px] border-collapse">
                        <thead>
                            <tr>
                                <th className="px-5 py-3.5 text-[0.72rem] font-medium tracking-[0.12em] uppercase text-left text-primary-foreground/45 border-b border-white/10 w-2/5">
                                    {criteriaLabel}
                                </th>
                                <th className="px-5 py-3.5 text-[0.72rem] font-medium tracking-[0.12em] uppercase text-left text-accent-light bg-accent/8 border-b border-white/10">
                                    {ourLabel}
                                </th>
                                <th className="px-5 py-3.5 text-[0.72rem] font-medium tracking-[0.12em] uppercase text-left text-primary-foreground/35 border-b border-white/10">
                                    {theirLabel}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {rows.map((row, i) => (
                                <tr
                                    key={row.criteria}
                                    className={`border-b border-white/5 transition-colors hover:bg-white/5 ${i % 2 === 0 ? "bg-white/5" : ""
                                        }`}
                                >
                                    <td className="px-5 py-3.5 text-sm text-primary-foreground/70">{row.criteria}</td>
                                    <td className="px-5 py-3.5 text-sm bg-accent/8">
                                        {typeof row.ours === "boolean" ? (
                                            row.ours ? (
                                                <Check className="w-[18px] h-[18px] text-green-400" strokeWidth={2.5} />
                                            ) : (
                                                <X className="w-[18px] h-[18px] text-white/25" strokeWidth={2.5} />
                                            )
                                        ) : (
                                            <span className="text-primary-foreground font-normal">{row.ours}</span>
                                        )}
                                    </td>
                                    <td className="px-5 py-3.5 text-sm">
                                        {typeof row.theirs === "boolean" ? (
                                            row.theirs ? (
                                                <Check className="w-[18px] h-[18px] text-green-400" strokeWidth={2.5} />
                                            ) : (
                                                <X className="w-[18px] h-[18px] text-white/25" strokeWidth={2.5} />
                                            )
                                        ) : (
                                            <span className="text-primary-foreground/35">{row.theirs}</span>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    );
}