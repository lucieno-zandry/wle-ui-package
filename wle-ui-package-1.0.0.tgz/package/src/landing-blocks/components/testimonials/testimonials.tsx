import { Star } from "lucide-react";

function StarRating({ rating, ariaLabel }: { rating: number; ariaLabel: string }) {
    return (
        <div className="flex gap-0.5" aria-label={ariaLabel}>
            {Array.from({ length: 5 }, (_, i) => (
                <Star
                    key={i}
                    className={`w-3.5 h-3.5 ${i < rating ? "text-accent fill-amber" : "text-border"}`}
                    strokeWidth={1.5}
                    fill={i < rating ? "currentColor" : "none"}
                />
            ))}
        </div>
    );
}

interface TestimonialsViewProps {
    eyebrow?: string;
    title: string;
    testimonials: Array<{
        id: string;
        author: string;
        location: string;
        avatar?: string;
        rating: number;
        text: string;
        verified: boolean;
    }>;
    verifiedPurchaseLabel: string;
    securePaymentViaLabel: string;
    ratingLabel: (rating: number) => string;
}

export function TestimonialsView({
    eyebrow,
    title,
    testimonials,
    verifiedPurchaseLabel,
    securePaymentViaLabel,
    ratingLabel,
}: TestimonialsViewProps) {
    return (
        <section className="py-xl bg-background border-t border-border" id="reviews">
            <div className="max-w-content mx-auto px-md">
                <div className="mb-lg">
                    {eyebrow && <p className="font-body text-[0.7rem] font-medium tracking-[0.18em] uppercase text-accent mb-xs">{eyebrow}</p>}
                    <h2 className="font-display text-[clamp(2rem,4vw,3.25rem)] font-medium leading-tight text-foreground mb-sm">{title}</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                    {testimonials.map((t, i) => (
                        <div
                            key={t.id}
                            className="relative bg-card border border-border rounded-md p-7 flex flex-col gap-4 transition-shadow hover:shadow-[0_8px_32px_rgba(44,31,15,0.1)] animate-[fade-up_0.5s_var(--ease-out-expo)_both]"
                            style={{ animationDelay: `${i * 100}ms` }}
                        >
                            <span className="absolute top-5 right-6 font-display text-5xl leading-none text-border select-none">
                                "
                            </span>
                            <StarRating rating={t.rating} ariaLabel={ratingLabel(t.rating)} />
                            <p className="text-[0.92rem] text-foreground-mid leading-relaxed flex-1">{t.text}</p>
                            <div className="flex items-center gap-3 mt-auto">
                                <div className="relative w-10 h-10 shrink-0">
                                    {t.avatar ? (
                                        <img src={t.avatar} alt={t.author} className="w-10 h-10 rounded-full object-cover" />
                                    ) : (
                                        <span className="absolute inset-0 bg-primary text-white rounded-full flex items-center justify-center text-sm font-medium">
                                            {t.author.charAt(0)}
                                        </span>
                                    )}
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-foreground flex items-center gap-1.5">
                                        {t.author}
                                        {t.verified && (
                                            <span className="text-[0.65rem] text-primary bg-primary/10 rounded-full px-1.5 py-0.5 tracking-wide">
                                                ✓
                                            </span>
                                        )}
                                    </p>
                                    <p className="text-[0.72rem] text-foreground-soft">{t.location}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="mt-lg pt-md border-t border-border flex flex-col sm:flex-row sm:items-center gap-4">
                    <p className="text-[0.72rem] tracking-[0.1em] uppercase text-foreground-soft">
                        {securePaymentViaLabel}
                    </p>
                    <div className="flex flex-wrap gap-2">
                        {["VISA", "Mastercard", "PayPal"].map((method) => (
                            <span
                                key={method}
                                className="px-2.5 py-1 border border-border rounded-sm text-[0.72rem] font-medium text-foreground-mid bg-card"
                            >
                                {method}
                            </span>
                        ))}
                        <span className="px-2.5 py-1 border border-primary/30 rounded-sm text-[0.72rem] font-medium text-primary bg-primary/5">
                            🔒 SSL
                        </span>
                    </div>
                </div>
            </div>
        </section>
    );
}