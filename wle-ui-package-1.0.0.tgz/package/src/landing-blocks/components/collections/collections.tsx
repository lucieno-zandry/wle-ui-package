import { PropsWithChildren } from "react";
import { type CollectionItemViewProps } from "./collection-item";
import { CollectionContent, CollectionContentItem, LandingBlock } from "wle-core";

type CollectionsProps = {
    block: LandingBlock<CollectionContent>;
    eyebrowFallback?: string
} & PropsWithChildren

export function Collections({ block, eyebrowFallback = "", children }: CollectionsProps) {
    const items = block.content?.items ?? [];
    const eyebrow = block.content?.eyebrow ?? eyebrowFallback;

    return (
        <section className="py-xl bg-background">
            <div className="max-w-content mx-auto px-md mb-lg">
                <p className="font-body text-[0.7rem] font-medium tracking-[0.18em] uppercase text-accent mb-xs">{eyebrow}</p>
                <h2 className="font-display text-[clamp(2rem,4vw,3.25rem)] font-medium leading-tight text-foreground mb-sm">{block.title}</h2>
                <p className="text-base text-foreground-mid max-w-text leading-relaxed">{block.subtitle}</p>
            </div>
            <div className="max-w-content mx-auto px-md grid grid-cols-1 sm:grid-cols-3 gap-5">
                {children}
            </div>
        </section>
    );
}