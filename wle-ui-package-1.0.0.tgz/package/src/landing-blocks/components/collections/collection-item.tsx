import { Link } from "react-router";
import { ArrowRight } from "lucide-react";

export type CollectionItemViewProps = {
    id: number;
    title: string;
    subtitle: string | null;
    imageUrl: string | null;
    startingPrice: number;
    index: number;
    formatMoney: (value: number) => string;
    linkTo: string;
    fromLabel: string;
    shopLabel: string;
};

export function CollectionItemView({
    title,
    subtitle,
    imageUrl,
    startingPrice,
    index,
    formatMoney,
    linkTo,
    fromLabel,
    shopLabel,
}: CollectionItemViewProps) {
    return (
        <Link
            to={linkTo}
            className="group relative flex flex-col rounded-md overflow-hidden bg-card cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-lg animate-[fade-up_0.6s_var(--ease-out-expo)_both]"
            style={{ animationDelay: `${index * 120}ms` }}
        >
            <div className="relative aspect-[3/4] overflow-hidden">
                {imageUrl ? (
                    <img
                        src={imageUrl}
                        alt={title}
                        className="w-full h-full object-cover transition-transform duration-600 group-hover:scale-104"
                        loading="lazy"
                    />
                ) : (
                    <div className="w-full h-full bg-accent/10" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            </div>

            <div className="p-5 flex flex-col gap-4 flex-1 justify-between">
                <div>
                    {subtitle && (
                        <p className="text-[0.68rem] tracking-[0.15em] uppercase font-bold text-accent mb-1">
                            {subtitle}
                        </p>
                    )}
                    <h3 className="font-display text-2xl font-medium text-foreground leading-tight">
                        {title}
                    </h3>
                </div>

                <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground-mid">
                        {fromLabel} {formatMoney(startingPrice)}
                    </span>
                    <span className="text-sm font-medium text-primary flex items-center gap-1 transition-all group-hover:gap-2">
                        {shopLabel} <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                </div>
            </div>
        </Link>
    );
}