interface StoryViewProps {
  eyebrow?: string;
  title: string;
  body: string;
  imageUrl: string | null;
  imageCaption?: string;
  stats: Array<{ value: string; label: string }>;
  defaultImageAlt: string;
}

export function StoryView({
  eyebrow,
  title,
  body,
  imageUrl,
  imageCaption,
  stats,
  defaultImageAlt,
}: StoryViewProps) {
  const headlineLines = title.split("\n");

  return (
    <section className="grid grid-cols-1 md:grid-cols-2 min-h-[520px] md:min-h-[680px] bg-background border-t border-border">
      <div className="relative overflow-hidden min-h-[320px] md:min-h-full">
        <div className="absolute inset-0">
          <img
            src={imageUrl ?? "/images/placeholder-story.jpg"}
            alt={imageCaption || defaultImageAlt}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          {imageCaption && (
            <p className="absolute bottom-3 left-3 right-3 text-[0.65rem] tracking-wide text-white/60 text-center">
              {imageCaption}
            </p>
          )}
        </div>
        <div className="hidden md:block absolute top-[10%] bottom-[10%] right-0 w-0.5 bg-gradient-to-b from-transparent via-amber to-transparent rounded-full" aria-hidden />
      </div>

      <div className="py-xl px-md md:px-lg flex flex-col justify-center gap-5">
        {eyebrow && <p className="font-body text-[0.7rem] font-medium tracking-[0.18em] uppercase text-accent mb-xs">{eyebrow}</p>}
        <h2 className="font-display text-[clamp(2.2rem,4vw,3.5rem)] font-medium leading-tight text-foreground">
          {headlineLines.map((line, i) => (
            <span key={i} className={i === 1 ? "italic text-primary" : ""}>
              {line}
              {i < headlineLines.length - 1 && <br />}
            </span>
          ))}
        </h2>
        <p className="text-base text-foreground-mid leading-relaxed max-w-[520px]">{body}</p>

        {stats.length > 0 && (
          <div className="flex flex-wrap gap-4 mt-1">
            {stats.map((stat, idx) => (
              <div key={idx} className="flex flex-col gap-0.5 border-l-2 border-accent pl-3">
                <span className="font-display text-[1.75rem] font-medium text-foreground leading-none">
                  {stat.value}
                </span>
                <span className="text-[0.7rem] tracking-[0.1em] uppercase text-foreground-soft">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
