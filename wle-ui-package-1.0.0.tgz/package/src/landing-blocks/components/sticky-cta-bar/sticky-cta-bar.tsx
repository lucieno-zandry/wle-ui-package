import { ShoppingCart, X } from "lucide-react";
import { Button } from "~/components/ui/button";

interface StickyCTABarViewProps {
    isVisible: boolean;
    productName: string;
    price: string;
    thumbnailUrl: string | null;
    onAddToCart: () => void;
    onDismiss: () => void;
    quickAddAriaLabel: string;
    addToCartLabel: string;
    dismissAriaLabel: string;
}

export function StickyCTABarView({
    isVisible,
    productName,
    price,
    thumbnailUrl,
    onAddToCart,
    onDismiss,
    quickAddAriaLabel,
    addToCartLabel,
    dismissAriaLabel,
}: StickyCTABarViewProps) {
    return (
        <div
            className={`fixed bottom-0 left-0 right-0 z-[100] bg-bark border-t border-primary-foreground/10 transition-transform duration-500 ease-out-expo shadow-[0_-8px_30px_rgba(0,0,0,0.2)] ${isVisible ? "translate-y-0" : "translate-y-full"
                }`}
            aria-hidden={!isVisible}
            role="complementary"
            aria-label={quickAddAriaLabel}
        >
            <div className="max-w-content mx-auto px-4 md:px-8 py-3 flex items-center gap-4">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                    {thumbnailUrl ? (
                        <img src={thumbnailUrl} alt={productName} className="w-10 h-10 rounded-sm object-cover shrink-0" />
                    ) : (
                        <div className="w-10 h-10 rounded-sm bg-accent/20 shrink-0" />
                    )}
                    <div className="flex flex-col min-w-0">
                        <p className="text-sm font-medium text-primary-foreground truncate">{productName}</p>
                        <p className="text-xs text-accent-light">{price}</p>
                    </div>
                </div>

                <Button onClick={onAddToCart} size="sm" className="bg-accent !text-foreground font-medium rounded-sm shrink-0">
                    <ShoppingCart className="w-4 h-4 mr-1.5" />
                    <span className="sticky-cta__btn-text">{addToCartLabel}</span>
                </Button>

                <button onClick={onDismiss} className="text-primary-foreground/40 hover:text-primary-foreground transition-colors p-1 shrink-0" aria-label={dismissAriaLabel}>
                    <X className="w-4 h-4" />
                </button>
            </div>
        </div>
    );
}