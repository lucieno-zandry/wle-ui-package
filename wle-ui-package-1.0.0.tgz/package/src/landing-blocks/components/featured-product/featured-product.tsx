import { Button } from "~/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router";
import { Product } from "wle-core";
import { PropsWithChildren } from "react";

interface FeaturedProductsViewProps extends PropsWithChildren {
    eyebrow?: string;
    title: string;
    subtitle?: string | null;
    products: Product[];
    viewAllProductsLabel: string;
    viewAllProductsLink: string;
}

export function FeaturedProductsView({
    eyebrow,
    title,
    subtitle,
    products,
    viewAllProductsLabel,
    viewAllProductsLink,
    children
}: FeaturedProductsViewProps) {
    return (
        <section className="py-xl bg-card border-t border-border" id="featured">
            <div className="max-w-content mx-auto px-md mb-lg">
                {eyebrow && <p className="font-body text-[0.7rem] font-medium tracking-[0.18em] uppercase text-accent mb-xs">{eyebrow}</p>}
                <h2 className="font-display text-[clamp(2rem,4vw,3.25rem)] font-medium leading-tight text-foreground mb-sm">{title}</h2>
                {subtitle && <p className="text-base text-foreground-mid max-w-text leading-relaxed">{subtitle}</p>}
            </div>

            <div className="max-w-content mx-auto px-md">
                {children}
            </div>

            <div className="max-w-content mx-auto px-md mt-lg flex justify-center">
                <Button asChild variant="outline" className="border-primary text-primary font-medium rounded-sm px-7 py-2.5 hover:bg-primary hover:text-white transition-colors">
                    <Link to={viewAllProductsLink}>
                        {viewAllProductsLabel}
                        <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                </Button>
            </div>
        </section>
    );
}