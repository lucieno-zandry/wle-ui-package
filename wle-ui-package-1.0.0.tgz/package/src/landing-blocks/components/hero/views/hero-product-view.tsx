import type { RefObject } from "react";
import { getEffectivePrice, getOriginalPrice, getPromotionBadge, getVariantLabel } from "../hero";
import { Button } from "~/components/ui/button";
import { ChevronDown, ShoppingCart } from "lucide-react";
import { Variant } from "wle-core";

interface HeroProductViewProps {
    backgroundImageUrl: string | null;
    headline: string;
    subline: string;
    variants: Variant[];
    selectedVariantId: string | null;
    onSelectVariant: (id: string) => void;
    onAddToCart: () => void;
    onScrollDown: () => void;
    sentinelRef: RefObject<HTMLDivElement | null>;
    formatMoney: (money: number) => string;
    eyebrow: string;
    headlineSuffix: string;
    trustLine: string;
    addToCartLabel: string;
    scrollDownAriaLabel: string;
    backgroundImageUrlFallback?: string;
    actionDisabled?: boolean,
}

export function HeroProductView({
    backgroundImageUrl,
    headline,
    subline,
    variants,
    selectedVariantId,
    onSelectVariant,
    onAddToCart,
    onScrollDown,
    sentinelRef,
    eyebrow,
    formatMoney,
    headlineSuffix,
    trustLine,
    addToCartLabel,
    scrollDownAriaLabel,
    backgroundImageUrlFallback = "https://images.unsplash.com/photo-1605000797499-95a51c5269ae",
    actionDisabled = false
}: HeroProductViewProps) {

    const selected = variants.find((v) => v.id === Number(selectedVariantId)) ?? variants[0];

    return (
        <section className="relative min-h-screen flex items-end pb-xl overflow-hidden pt-10 sm:pt-0">
            <div className="absolute inset-0 z-0">
                <img
                    src={backgroundImageUrl ?? backgroundImageUrlFallback}
                    alt=""
                    className="w-full h-full object-cover object-center md:object-[center_30%]"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/15 via-black/55 to-black/90" />
            </div>

            <div className="relative z-10 w-full max-w-content mx-auto px-md pb-12 flex flex-col gap-4">
                <p className="flex items-center gap-2 text-[0.7rem] font-medium tracking-[0.2em] uppercase text-accent-light">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-accent-light animate-pulse-dot" />
                    {eyebrow}
                </p>

                <h1 className="font-display text-[clamp(3rem,8vw,6.5rem)] font-medium leading-none text-primary-foreground">
                    {headline} <em className="italic text-accent-light">{headlineSuffix}</em>
                </h1>

                <p className="text-[clamp(0.95rem,1.5vw,1.1rem)] text-primary-foreground/80 max-w-[520px] leading-relaxed">
                    {subline}
                </p>

                {variants.length > 1 && (
                    <div className="flex flex-wrap gap-2 mt-1">
                        {variants.map((v) => {
                            const isActive = (selectedVariantId ?? String(variants[0]?.id)) === String(v.id);
                            const badge = getPromotionBadge(v);
                            return (
                                <button
                                    key={v.id}
                                    onClick={() => onSelectVariant(String(v.id))}
                                    className={`
                    relative px-4 py-1.5 rounded-full border backdrop-blur-sm transition-all
                    ${isActive
                                            ? "bg-accent border-accent text-foreground font-medium"
                                            : "border-primary-foreground/30 bg-ivory/5 text-primary-foreground hover:bg-ivory/20 hover:border-primary-foreground/60"
                                        }
                  `}
                                >
                                    {getVariantLabel(v)}
                                    {badge && (
                                        <span className="absolute -top-2 -right-1.5 bg-primary text-white text-[0.55rem] font-medium px-1 py-px rounded-full">
                                            {badge}
                                        </span>
                                    )}
                                </button>
                            );
                        })}
                    </div>
                )}

                <div className="flex flex-col sm:flex-row sm:items-center gap-4 mt-2">
                    <div className="flex flex-col">
                        {selected &&
                            (() => {
                                const original = getOriginalPrice(selected);
                                const current = getEffectivePrice(selected);
                                return (
                                    <>
                                        {original && (
                                            <span className="text-sm text-primary-foreground/45 line-through">
                                                {formatMoney(original)}
                                            </span>
                                        )}
                                        <span className="font-display text-[clamp(1.8rem,3vw,2.4rem)] font-medium text-primary-foreground leading-tight">
                                            {formatMoney(current)}
                                        </span>
                                    </>
                                );
                            })()}
                    </div>

                    <Button
                        onClick={onAddToCart}
                        size="lg"
                        className="bg-accent !text-foreground font-medium rounded-sm px-7 py-3 shadow-[0_4px_20px_rgba(200,133,26,0.35)] hover:bg-accent-light hover:-translate-y-px transition-all"
                        disabled={actionDisabled}
                    >
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        {addToCartLabel}
                    </Button>
                </div>

                <p className="text-xs tracking-wide text-primary-foreground/50">{trustLine}</p>
            </div>

            <div ref={sentinelRef} className="absolute bottom-0 w-px h-px pointer-events-none" aria-hidden />
            <button
                onClick={onScrollDown}
                className="absolute bottom-6 right-8 z-20 w-10 h-10 rounded-full border border-primary-foreground/30 bg-ivory/5 text-primary-foreground flex items-center justify-center cursor-pointer backdrop-blur-sm transition-all hover:bg-ivory/15 animate-bounce-down"
                aria-label={scrollDownAriaLabel}
            >
                <ChevronDown className="w-5 h-5" />
            </button>
        </section>
    );
}
