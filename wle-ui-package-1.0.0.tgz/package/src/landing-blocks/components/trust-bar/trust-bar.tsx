import { LucideIcon } from "./lucide-icon";

interface TrustPillar {
    id: string;
    title: string;
    description: string;
    icon: string;
}

interface TrustBarViewProps {
    pillars: TrustPillar[];
}

export function TrustBarView({ pillars }: TrustBarViewProps) {
    if (!pillars.length) return null;

    return (
        <section className="bg-primary py-md border-b border-white/10">
            <div className="max-w-content mx-auto px-md grid grid-cols-2 md:grid-cols-4 gap-4">
                {pillars.map((pillar, i) => (
                    <div
                        key={pillar.id}
                        className="flex items-start gap-3 animate-[fade-up_0.5s_var(--ease-out-expo)_both]"
                        style={{ animationDelay: `${i * 80}ms` }}
                    >
                        <span className="w-9 h-9 rounded-sm bg-white/10 flex items-center justify-center shrink-0">
                            <LucideIcon name={pillar.icon} className="w-[18px] h-[18px] text-accent-light" strokeWidth={1.5} />
                        </span>
                        <div>
                            <p className="text-sm font-medium text-white leading-tight mb-0.5">{pillar.title}</p>
                            <p className="text-xs text-white/55 leading-relaxed">{pillar.description}</p>
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
}