import { ChevronDown } from "lucide-react";

interface FaqViewProps {
    eyebrow?: string;
    title: string;
    items: Array<{ id: string; question: string; answer: string }>;
    openId: string | null;
    onToggle: (id: string) => void;
}

export function FaqView({ eyebrow, title, items, openId, onToggle }: FaqViewProps) {
    return (
        <section className="py-xl bg-card border-t border-border" id="faq">
            <div className="max-w-[780px] mx-auto px-md">
                <div className="mb-lg">
                    {eyebrow && <p className="font-body text-[0.7rem] font-medium tracking-[0.18em] uppercase text-accent mb-xs">{eyebrow}</p>}
                    <h2 className="font-display text-[clamp(2rem,4vw,3.25rem)] font-medium leading-tight text-foreground mb-sm">{title}</h2>
                </div>
                <div className="flex flex-col">
                    {items.map((item) => {
                        const isOpen = openId === item.id;
                        return (
                            <div
                                key={item.id}
                                className={`border-b border-border first:border-t ${isOpen ? "text-primary" : ""}`}
                            >
                                <button
                                    className="w-full py-5 flex items-center justify-between gap-4 text-left bg-transparent border-none cursor-pointer"
                                    onClick={() => onToggle(item.id)}
                                    aria-expanded={isOpen}
                                    aria-controls={`faq-answer-${item.id}`}
                                >
                                    <span className={`font-display text-lg font-medium leading-tight transition-colors ${isOpen ? "text-primary" : "text-foreground"}`}>
                                        {item.question}
                                    </span>
                                    <ChevronDown
                                        className={`w-[18px] h-[18px] shrink-0 transition-all duration-300 ${isOpen ? "rotate-180 text-primary" : "text-foreground-soft"}`}
                                        strokeWidth={1.5}
                                    />
                                </button>
                                <div
                                    id={`faq-answer-${item.id}`}
                                    aria-hidden={!isOpen}
                                    style={{
                                        maxHeight: isOpen ? "400px" : "0px",
                                        overflow: "hidden",
                                        transition: "max-height 0.35s cubic-bezier(0.4, 0, 0.2, 1)",
                                    }}
                                >
                                    <p className="text-[0.95rem] text-foreground-mid leading-relaxed pb-5">{item.answer}</p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </section>
    );
}